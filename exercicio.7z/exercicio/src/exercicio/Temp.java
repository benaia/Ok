package exercicio;

public class Temp {
	public static void main(String[] args) {
		//(F� - 32) * 5/9 = C�
		
		
	}

}
