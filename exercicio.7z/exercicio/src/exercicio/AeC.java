package exercicio;

public class AeC {
	public static void main(String[] args) {
		double R = 3.4;
		final double Pi = 3.14159;
		
		double cir = Pi * R * R;
		
		System.out.println(cir);
		
	}
}
