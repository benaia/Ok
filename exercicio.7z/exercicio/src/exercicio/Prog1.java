package exercicio;

public class Prog1 {
	public static void main(String[] args) {
		
		System.out.println("Fala Zeze, bom dia cara!!!");
		
	}

}
